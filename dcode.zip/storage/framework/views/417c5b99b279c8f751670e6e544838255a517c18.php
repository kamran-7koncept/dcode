

<?php $__env->startSection('content'); ?>

<div id="demo" class="carousel slide margin-t-35 " data-ride="carousel">
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="<?php echo e(asset('./storage/images/sliders/slider-1.jpg')); ?>" alt="Los Angeles" width="1100" height="500">
      <div class="carousel-caption">
        <h3>Los Angeles</h3>
        <p>We had such a great time in LA!</p>
      </div>   
    </div>
    <div class="carousel-item">
      <img src="<?php echo e(asset('./storage/images/sliders/slider-2.jpg')); ?>" alt="Chicago" width="1100" height="500">
      <div class="carousel-caption">
        <h3>Chicago</h3>
        <p>Thank you, Chicago!</p>
      </div>   
    </div>
    <div class="carousel-item">
      <img src="<?php echo e(asset('./storage/images/sliders/slider-3.jpg')); ?>" alt="New York" width="1100" height="500">
      <div class="carousel-caption">
        <h3>New York</h3>
        <p>We love the Big Apple!</p>
      </div>   
    </div>
  </div>
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>

    <div class="container" style="margin-top: 80px">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Products</li>
            </ol>
        </nav>
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div class="row">
                    <div class="col-lg-7">
                        <h4>Products In Our Store</h4>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4">
                            <div class="card" style="margin-bottom: 20px; height: auto;">
                                <img src='<?php echo e(asset("./storage/images/$pro->image_path")); ?>'class="card-img-top mx-auto"
                                     style="height: 150px; width: 150px;display: block;"
                                     alt="<?php echo e($pro->image_path); ?>">
                                <div class="card-body">
                                    <a href=""><h6 class="card-title"><?php echo e($pro->name); ?></h6></a>
                                    <p>$<?php echo e($pro->price); ?></p>
                                    <form action="<?php echo e(route('cart.store')); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        <input type="hidden" value="<?php echo e($pro->id); ?>" id="id" name="id">
                                        <input type="hidden" value="<?php echo e($pro->name); ?>" id="name" name="name">
                                        <input type="hidden" value="<?php echo e($pro->price); ?>" id="price" name="price">
                                        <input type="hidden" value="<?php echo e($pro->image_path); ?>" id="img" name="img">
                                        <input type="hidden" value="<?php echo e($pro->slug); ?>" id="slug" name="slug">
                                        <input type="hidden" value="1" id="quantity" name="quantity">
                                        <div class="card-footer" style="background-color: white;">
                                              <div class="row">
                                                <button class="btn btn-secondary btn-sm" class="tooltip-test" title="add to cart">
                                                    <i class="fa fa-shopping-cart"></i> add to cart
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/shop.blade.php ENDPATH**/ ?>
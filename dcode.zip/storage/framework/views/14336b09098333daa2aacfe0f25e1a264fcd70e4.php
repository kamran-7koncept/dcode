<?php
 
 $path= Request::path();

?>
<nav class="navbar navbar-expand-md  bg-white navbar-light  fixed-top">
    <div class="container">
        <a class="navbar-brand" href="/"><img width="193" src="<?php echo e(asset('./storage/layout_images/code_logo.png')); ?>"></a>
        <button type="button" class="navbar-toggler bg-light" data-toggle="collapse" data-target="#nav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-between ml-auto code-mobile-site-nav" id="nav">
            <ul class="navbar-nav  ml-auto font-17">
                <li class="nav-item">
                    <a class="nav-link px-3" href="#">About Dcode</a>
                </li>
                 <li class="nav-item">
                    <a class="nav-link px-3" href="/compare-specifications">Compare</a>
                </li>
                 
                <li class="nav-item">
                    <a class="nav-link   px-3" href="/dealers">Store Locator</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link  px-3" href="/products">World of Dcode</a>
                </li>
            </ul>
            <!-- Search bar -->
           <!--  <form class="form-inline ml-3">
                <div class="search-button">
                    <i class="fa fa-search text-purple"> </i>
                </div>
                <div class="search-box">
                    <input type="text" name="Search" class="pl-2" placeholder="Search ..."/>
                    <input type="button" value="Search"/>
                </div>
            </form> -->
            <?php if($path == "dealers" || $path == "compare-specifications" || $path == "/" || $path == "order" || $path == "about-us" || $path == "terms-conditions" || $path == "policies"): ?>

                <?php else: ?>
                <form method="POST" action='<?php echo e(url("/order/")); ?>'>
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                    <button class="btn btn-success order-button btn-yellow btn-padding-sm
             btn-square font-19 ml-3 mt-2 mt-md-0"
                    type="submit">Order
                Now
            </button>
            </form>
            <?php endif; ?>
        </div>
    </div>
</nav><?php /**PATH C:\xampp\htdocs\dcode\resources\views/include/navbar.blade.php ENDPATH**/ ?>
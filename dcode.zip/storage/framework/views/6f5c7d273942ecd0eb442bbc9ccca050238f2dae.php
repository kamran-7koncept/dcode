 <?php echo $__env->make('admin.layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php echo $__env->make('admin.layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <strong class="h3 mb-2 text-gray-800">Mobiles</strong> 
                    <a  href="/mobile/create" class="btn btn-info float-right w-25" name="create" value="Create">Create</a>
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4 " style="margin-top: 20px"> 
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered dt-responsive nowrap" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Sr#</th>
                                            <th>Image</th>
                                            <th>Name</th>
                                            <th>Price</th>
                                            <th>Shipping Cost</th>
                                            <th>Description</th> 
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                     
                                    <tbody>
                                        <?php $count =1;?>
                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            
                                            <td><?php echo e($count++); ?></td>
                                            <td><img src='<?php echo e(url("/images/$product->image_path")); ?>' class="card-img-top mx-auto" alt="<?php echo e($product->image_path); ?>"></td>
                                            <td><?php echo e($product->name); ?></td>
                                            <td><?php echo e($product->price); ?></td>
                                            <td><?php echo e($product->shipping_cost); ?></td>
                                            <td><?php echo e($product->description); ?></td>
                                            <td><button class="btn btn-info">edit</button></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
 <?php echo $__env->make('admin.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    <?php /**PATH C:\xampp\htdocs\blog\resources\views/admin/mobiles.blade.php ENDPATH**/ ?>